<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
    <style>
        html, body {
            background-image: url('https://i.pinimg.com/originals/e4/a0/9c/e4a09c71c4da7b3dfa51dc724b8bdb9b.gif');
            background-size: cover;
            background-position: center;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            color: #fff;
            height: 100vh;
            margin: 0;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
            animation: textAnimation 3s infinite alternate;
            /* Define your preferred animation */
        }

        @keyframes textAnimation {
            0% { transform: scale(1); }
            100% { transform: scale(1.1); }
        }

        .links > a {
            color: #fff;
            padding: 10px 25px;
            font-size: 18px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
            transition: background-color 0.3s;
            margin: 10px;
            border: 2px solid #fff;
            border-radius: 25px;
        }

        .links > a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body>
    <div class="content">
        <div class="title">
            Socio
        </div>

        <div class="links">
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
        </div>
    </div>
</body>
</html>
