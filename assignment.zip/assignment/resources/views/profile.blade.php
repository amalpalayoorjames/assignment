<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Styles -->
    <style>
        /* Add your custom styles here */

        /* General styles */
        html, body {
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            margin: 0;
            padding: 0;
            background-image: url('https://media.istockphoto.com/id/1370945549/vector/mobile-applications.jpg?s=612x612&w=0&k=20&c=kfzhPhcNW1c6u-6nLvdT3hBAiy4KoJUahBrbnXOPqmg=');
            background-size: cover;
            background-position: center;
            /* height: 100vh; */
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding-left: 200px;
            padding-right: 200px;
            border-radius: 10px;
            text-align: center;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Styling for the input fields and button */
        input[type="text"],
        textarea,
        input[type="file"],
        button {
            margin-bottom: 15px;
            padding: 8px;
            border: none;
            border-radius: 5px;
            background-color: #fff;
            width: 100%;
            max-width: 300px;
            box-sizing: border-box; /* Ensure padding doesn't affect width */
        }

        button {
            cursor: pointer;
            background-color: #4CAF50;
            color: #fff;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Additional styles for the icon links */
        .icons {
            margin-top: 20px;
        }

        .icons a {
            color: #fff;
            margin: 0 10px;
            font-size: 24px;
            transition: transform 0.3s;
        }

        .icons a:hover {
            transform: scale(1.2);
        }

        /* Style for the "Add Post" section as an alert */
        .add-post {
            background-color:  	#D3D3D3; /* Alert red color */
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: inline-block; /* Make the container shrink to fit content */
            text-align: left; /* Align content to the left */
        }
    </style>
</head>
<body>

<div class="container">
    <h1> <i class="fa-regular fa-user"></i>- {{ $user->name }}</h1>

    <div class="add-post">
        <h2>Add Post</h2>
        <form action="/profile" method="post" enctype="multipart/form-data" >
    @csrf

    
        <input type="text" name="title" placeholder="Title">
   
<br>
  
        <textarea name="description" rows="4" placeholder="Description" required></textarea>
   


        <input type="file" name="image" placeholder="image">
   

    <button type="submit" style="width: 100%; max-width: 300px; box-sizing: border-box; padding: 8px; margin-top: 10px; cursor: pointer;">Add Post</button>
</form>

    </div>

    <div class="user-posts">
        <h2>User Posts</h2>
        <style>
            .user-posts ul {
                list-style: none;
                display: flex;
                flex-wrap: wrap;
                justify-content: space-around;
                padding: 0;
                margin: 0;
            }

            .user-posts li {
                background-color: rgba(0, 0, 0, 0.7);
                padding: 10px;
                border-radius: 5px;
                margin: 5px;
                transition: transform 0.3s;
                width: 200px; /* Set your preferred width */
            }

            .user-posts li:hover {
                transform: translateY(-5px); /* Move the post up slightly on hover */
            }

            .user-posts li strong {
                display: block;
                margin-bottom: 5px;
                color: #fff;
            }

            .user-posts li img {
                max-width: 100%;
                max-height: 150px;
                border-radius: 5px;
            }

            hr {
                margin: 5px 0;
                border: none;
                border-top: 1px solid #fff;
            }
        </style>
        <ul>
            @if($posts->count() > 0)
                @foreach($posts as $post)
                    <li>
                        <strong>Title:</strong> {{ $post->title }}
                        <strong>Description:</strong> {{ $post->description }}
                        @if($post->image)
                            <img src="{{ asset('storage/' . $post->image) }}" alt="Post Image">
                        @endif
                        <hr>
                    </li>
                @endforeach
            @else
                <p>No posts yet.</p>
            @endif
        </ul>
    </div>

    <a href="/dashboard" style="text-decoration: none; color: #fff; display: block; margin-top: 20px;">
        <button style="padding: 10px 20px; background-color: #4CAF50; color: #fff; border: none; border-radius: 5px; cursor: pointer;">
            Back to Home
        </button>
    </a>
</div>

</body>
</html>



