<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    

    public function store(Request $request)
    {
        // Validate the request
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Get the authenticated user
        $user = Auth::user();

        // Create a new Post instance
        $post = new Post();
        $post->title = $request->input('title');
        $post->description = $request->input('description');
        $post->user_id = $user->id;

        // Handle image upload
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('images', 'public');
            $post->image = $imagePath;
        }

        // Save the post associated with the authenticated user
        // $user->posts()->save($post);
        $post->save();

        // Redirect to the user's profile with a success message
        return redirect()->route('profile', $user)->with('success', 'Post added successfully.');
    }

    public function show(User $user)
    {
        // Retrieve and display the user's posts
        $posts = $user->posts()->latest()->get();
        return view('posts', compact('user', 'posts'));
    }
    public function allPosts()
    {
        // Retrieve all posts from the database
        $posts = Post::latest()->get();

        // Pass the posts to the view
        return view('all_posts', compact('posts'));
    }
}
