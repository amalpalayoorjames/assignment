<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            margin: 0;
            padding: 20px;
        }

        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar a.active {
            background-color: #007bff;
            color: white;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
        }
        .post-container {
            width: 100%;
            max-width: 600px;
            margin-bottom: 20px;
            background-color: black;
            color: white;
        }

        .post {
            background-color: rgba(255, 255, 255, 0.1);
            border: 2px solid white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .post:hover {
            border-color: red; /* Change border color on hover */
        }

        .post-info {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .post-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .post-info .username {
            font-weight: bold;
        }

        .post-content {
            margin-bottom: 10px;
        }

        .post-image {
            max-width: 100%;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .post-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 10px;
            border-top: 1px solid white;
        }

        .post-actions i {
            font-size: 24px;
            margin-right: 10px;
            cursor: pointer;
            color: white;
        }

        .heart-red {
            color: red; /* Change color when clicked */
        }
        .comment-section {
            display: none;
            margin-top: 10px;
            border-top: 1px solid white;
            padding-top: 10px;
        }

        .comment-section textarea {
            width: calc(100% - 40px);
            height: 60px;
            border: 1px solid white;
            border-radius: 5px;
            padding: 5px;
            resize: none;
            color: black;
            margin-bottom: 10px;
        }

        .comment-section button {
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .comment-section button:hover {
            background-color: #45a049;
        }
        .like-btn,
        .comment-btn {
            background: none;
            border: none;
            cursor: pointer;
            color: white;
            font-size: 18px;
            display: flex;
            align-items: center;
        }

        .like-btn:focus,
        .comment-btn:focus {
            outline: none;
        }

        .like-btn i,
        .comment-btn i {
            margin-right: 5px;
        }

        .like-btn i::before,
        .comment-btn i::before {
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            content: '\f004';
        }

        .comment-btn i::before {
            content: '\f075';
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a class="active" href="#home">Home</a>
       
        <a href="/logout">Logout</a>
    </div>

    <h2>Admin Dashboard</h2>
    <p>Welcome, <?php echo e(auth()->user()->name); ?>!</p>

    <!-- Content of your admin dashboard -->
     <!-- Sample Post Structure -->
     <div class="post-container">
        <?php if($posts->count() > 0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">
                    <div class="post-info">
                       
                        <div class="username"><?php echo e($post->user->name); ?></div>
                    </div>
                    <div class="post-content">
                        <p><strong>Title:</strong> <?php echo e($post->title); ?></p>
                        <p><strong>Description:</strong> <?php echo e($post->description); ?></p>
                    </div>
                    <ul class="comment-list">
                            
                            <li>Great post!</li>
                            <li>Nice picture!</li>
                            
                        </ul>
                    <?php if($post->image): ?>
                        <img class="post-image" src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="Post Image">
                    <?php endif; ?>
                      
                    <div class="post-actions">
                        <button class="like-btn"><i class="fas fa-heart"></i></button> <!-- Like button -->
                        <button class="comment-btn"><i class="fas fa-comment"></i></button> <!-- Comment button -->
                        <div class="comment-section">
                            <textarea placeholder="Enter your comment"></textarea>
                            <button class="post-comment-btn">Post Comment</button>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>No posts yet.</p>
        <?php endif; ?>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\sanshiya\assignment\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>