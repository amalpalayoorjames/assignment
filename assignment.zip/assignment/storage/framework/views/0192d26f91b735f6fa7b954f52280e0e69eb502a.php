<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>User Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: black;
            background-size: cover;
            background-position: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: white;
            padding: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        .post-container {
            width: 80%;
            max-width: 600px;
            margin-bottom: 20px;
        }

        .post {
            background-color: rgba(255, 255, 255, 0.1);
            border: 2px solid white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .post:hover {
            border-color: red; /* Change border color on hover */
        }

        .post-info {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .post-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .post-info .username {
            font-weight: bold;
        }

        .post-content {
            margin-bottom: 10px;
        }

        .post-image {
            max-width: 100%;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .post-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 10px;
            border-top: 1px solid white;
        }

        .post-actions i {
            font-size: 24px;
            margin-right: 10px;
            cursor: pointer;
            color: white;
        }

        .heart-red {
            color: red; /* Change color when clicked */
        }
        .comment-section {
            display: none;
            margin-top: 10px;
            border-top: 1px solid white;
            padding-top: 10px;
        }

        .comment-section textarea {
            width: calc(100% - 40px);
            height: 60px;
            border: 1px solid white;
            border-radius: 5px;
            padding: 5px;
            resize: none;
            color: black;
            margin-bottom: 10px;
        }

        .comment-section button {
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .comment-section button:hover {
            background-color: #45a049;
        }
        .like-btn,
        .comment-btn {
            background: none;
            border: none;
            cursor: pointer;
            color: white;
            font-size: 18px;
            display: flex;
            align-items: center;
        }

        .like-btn:focus,
        .comment-btn:focus {
            outline: none;
        }

        .like-btn i,
        .comment-btn i {
            margin-right: 5px;
        }

        .like-btn i::before,
        .comment-btn i::before {
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            content: '\f004';
        }

        .comment-btn i::before {
            content: '\f075';
        }
    </style>
</head>
<body>
    <h2>POSTS</h2>
    <p>Welcome, <?php echo e(auth()->user()->name); ?>!</p>
    <a href="/profile"><i class="fa-regular fa-user"></i></a>
    <br>

    <!-- Sample Post Structure -->
    <div class="post-container">
        <?php if($posts->count() > 0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post">
                    <div class="post-info">
                        
                        <div class="username"><?php echo e($post->user->name); ?></div>
                    </div>
                    <div class="post-content">
                        <p><strong>Title:</strong> <?php echo e($post->title); ?></p>
                        <p><strong>Description:</strong> <?php echo e($post->description); ?></p>
                    </div>
                    <?php if($post->image): ?>
                        <img class="post-image" src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="Post Image">
                    <?php endif; ?>
                    
                    <div class="post-actions">
                        <button class="like-btn"><i class="fas fa-heart"></i></button> <!-- Like button -->
                        <button class="comment-btn"><i class="fas fa-comment"></i></button> <!-- Comment button -->
                        <div class="comment-section">
                            <textarea placeholder="Enter your comment"></textarea>
                            <button class="post-comment-btn">Post Comment</button>
                            <ul class="comment-list">
                            
                            <li>Great post!</li>
                            <li>Nice picture!</li>
                            
                        </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>No posts yet.</p>
        <?php endif; ?>
    </div>

    <a href="/logout"><i class="fa-solid fa-right-from-bracket"></i></a>

    <!-- Font Awesome CDN -->
    <script src="https://kit.fontawesome.com/your-fontawesome-kit-id.js" crossorigin="anonymous"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to append comments below each post
            function addComment(postElement, comment) {
                const commentList = postElement.querySelector('.comment-list');
                const newComment = document.createElement('li');
                newComment.textContent = comment;
                commentList.appendChild(newComment);
            }

            // Toggle heart icon color on like button click
            document.querySelectorAll('.like-btn').forEach(function(likeBtn) {
                likeBtn.addEventListener('click', function(event) {
                    event.preventDefault();
                    likeBtn.querySelector('i').classList.toggle('heart-red');
                });
            });

            // Toggle comment section on comment button click
            document.querySelectorAll('.comment-btn').forEach(function(commentBtn) {
                commentBtn.addEventListener('click', function(event) {
                    event.preventDefault();
                    const commentSection = commentBtn.nextElementSibling;
                    const postElement = commentBtn.closest('.post');
                    const commentList = postElement.querySelector('.comment-list');

                    // Toggle comment section visibility
                    if (commentSection.style.display === 'block') {
                        commentSection.style.display = 'none';
                    } else {
                        commentSection.style.display = 'block';

                        // Append existing comments below the post
                        commentList.innerHTML = '';
                        // ... logic to fetch existing comments from your backend/API and add them here
                    }
                });
            });

            // Post comment functionality
            document.querySelectorAll('.comment-section button').forEach(function(postCommentBtn) {
                postCommentBtn.addEventListener('click', function(event) {
                    event.preventDefault();
                    const commentSection = postCommentBtn.parentElement;
                    const commentTextArea = commentSection.querySelector('textarea');
                    const comment = commentTextArea.value.trim();
                    if (comment !== '') {
                        const postElement = commentSection.parentElement;
                        const commentList = postElement.querySelector('.comment-list');
                        addComment(postElement, comment);
                        commentTextArea.value = ''; // Clear the comment textarea after posting
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\sanshiya\assignment\resources\views/dashboard.blade.php ENDPATH**/ ?>