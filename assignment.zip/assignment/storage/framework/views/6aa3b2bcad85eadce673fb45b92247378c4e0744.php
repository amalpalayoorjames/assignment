


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <style>
        html, body {
            background-image: url('https://t3.ftcdn.net/jpg/02/63/02/06/360_F_263020636_XbcbkduASNcEPkzwZEcIuj3nHZAQ0yFO.webp');
            background-size: cover;
            background-position: center;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            color: #fff;
            height: 100vh;
            margin: 0;
            overflow: hidden;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
            height: 100vh;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
            margin-bottom: 30px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        input[type="email"],
        input[type="password"],
        button {
            padding: 12px 15px;
            border: none;
            border-radius: 25px;
            margin: 10px;
            width: 250px;
            font-size: 16px;
        }

        input[type="email"],
        input[type="password"] {
            background-color: rgba(255, 255, 255, 0.8);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            outline: none;
            padding: 12px 15px;
            border: none;
            border-radius: 25px;
            margin: 10px;
            width: 250px;
            font-size: 16px;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        button {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
            border-radius: 25px;
            font-size: 16px;
            text-transform: uppercase;
        }

        button:hover {
            background-color: #45a049;
        }

        .links > a {
            color: #fff;
            padding: 10px 25px;
            font-size: 16px;
            font-weight: 600;
            letter-spacing: 1px;
            text-decoration: none;
            text-transform: uppercase;
            transition: background-color 0.3s;
        }

        .links > a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>

<div class="flex-center">
    <div class="content">
        <div class="title">
            
        </div>
        <form action="/login" method="post">
        <?php echo csrf_field(); ?>
                
                <input type="email" name="email" required placeholder="Enter the Username">
                
          
                <input type="password" name="password" required placeholder="Enter the Password"><br><br>
           
                <button type="submit">Login</button>
        </form>
        <br>
        <br>
        <div class="links">
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('register')); ?>">Register</a>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\sanshiya\assignment\resources\views/login.blade.php ENDPATH**/ ?>