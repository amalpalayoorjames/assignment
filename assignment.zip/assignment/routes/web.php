<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Http\Controllers\UserController;
use App\Http\Controllers\PostController;

Route::get('/', function () {
    return view('home');
})->name('home'); 

Route::get('/logout', function () {
    // Perform logout logic here if needed
    auth()->logout();

    // Redirect to home or login page after logout
    return redirect()->route('home');
})->name('logout'); // Name it 'logout' or any other name you prefer


Route::get('/register', function () {
    return view('register');
})->name('register');

Route::post('/register', [UserController::class, 'register']);

Route::get('/login', function () {
    return view('login');
})->name('login'); // Make sure to name the login route

Route::post('/login', [UserController::class, 'login']);

Route::get('/dashboard', function () {
    // Retrieve all posts from the database
    $posts = \App\Post::latest()->get();

    // Pass the posts to the view
    return view('dashboard', compact('posts'));
})->middleware('auth');

Route::get('/admin/dashboard', function () {
    if (auth()->check() && auth()->user()->role === 'admin') {
        $posts = \App\Post::latest()->get();
        return view('admin.dashboard', compact('posts'));
    } else {
        abort(403, 'Unauthorized');
    }
})->middleware('auth');
use App\Post;

Route::get('/profile', function () {
    $user = auth()->user();
    $posts = Post::where('user_id', $user->id)->latest()->get();

    return view('profile', compact('user', 'posts'));
})->name('profile')->middleware('auth');

Route::post('/profile', [PostController::class, 'store']);